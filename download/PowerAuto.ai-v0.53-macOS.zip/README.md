# PowerAuto.ai v0.53 for macOS

## 🚀 快速開始

### 系統要求
- macOS 10.15 (Catalina) 或更高版本
- Python 3.8 或更高版本
- 2GB 可用內存
- 1GB 可用磁盤空間

### 安裝步驟

1. **安裝 Python**
   ```bash
   # 使用 Homebrew (推薦)
   brew install python
   
   # 或訪問 https://python.org/downloads
   ```

2. **安裝 PowerAuto.ai**
   - 將 `PowerAuto.ai.app` 拖拽到 `應用程序` 文件夾
   - 雙擊啟動應用

3. **首次運行**
   - 系統可能提示安全警告
   - 前往 `系統偏好設置` > `安全性與隱私`
   - 點擊 `仍要打開` 允許運行

### 功能特色

🔒 **隱私保護** - 本地AI處理，代碼永不上傳
⚡ **智能決策** - 精準匹配最佳AI模型和處理策略  
🤖 **協同作業** - 多個AI智能體協同工作
📚 **持續學習** - 學習項目上下文，提供個性化體驗

### 終端運行

也可以在終端中直接運行：
```bash
cd /Applications/PowerAuto.ai.app/Contents/Resources
python3 powerauto.py
```

### 技術支持

- 官網：https://powerauto.ai
- 郵箱：support@powerauto.ai
- 文檔：https://powerauto.ai/docs

---
PowerAuto.ai Team © 2025
