PowerAuto.ai v0.53 - Windows 版本

安裝說明：
1. 確保已安裝 Python 3.8 或更高版本
2. 雙擊 PowerAuto.ai.bat 啟動程序
3. 或在命令行中運行：python powerauto.py

系統要求：
- Windows 10 或更高版本
- Python 3.8+
- 2GB 可用內存

技術支持：support@powerauto.ai
官方網站：https://powerauto.ai
